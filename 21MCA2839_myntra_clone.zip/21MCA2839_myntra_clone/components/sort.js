function sort(){
    return ` <ul>
    <li>
      <button>
        <p><span style="font-weight: bold">Price : Low to High </span></p>
      </button>
    </li>
    <li>
      <button>
        <p><span style="font-weight: bold">Price : Low to High </span></p>
      </button>
    </li>
  </ul> `
}


export {sort};