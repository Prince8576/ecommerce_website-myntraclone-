const women = () =>{
    return `<div class="firstCol">
    <ul>
        <li class="cat2">Indian & Fusion Wear</li>
        <li>Kurtas & Suits</li>
        <li>Kurtis, Tunics & Tops</li>
        <li>Ethnic Wear</li>
        <li>Leggings, Salwars & Churidars</li>
        <li>Skirts & Palazzos</li>
        <li>Sarees</li>
        <li>Dress Materials</li>
        <li>Lehenga Cholis</li>
        <li>Dupattas & Shawls</li>
        <li>Jackets</li>
        <li id="lastList"></li>
    </ul>
    <ul>
        <li class="cat2">Belts, Scarves & More</li>
      </ul>
      <ul>
        <li class="cat2">Watches & Wearables</li>
      </ul>
</div>
<div class="firstCol backCol">
    <ul>
        <li class="cat2">Western Wear</li>
        <li>Dresses</li>
        <li>Jumpsuits</li>
        <li>Tops</li>
        <li>Jeans</li>
        <li>Trousers & Capris</li>
        <li>Shorts & Skirts</li>
        <li>Shrugs</li>
        <li>Sweaters & Sweatshirts</li>
        <li>Jackets & Coats</li>
        <li>Blazers & Waistcoats</li>
        <li id="lastList"></li>
    </ul>
    <ul>
        <li class="cat2">Plus Size</li>
    </ul>
    <ul>
        <li class="cat2">Sunglasses & Frames</li>
    </ul>
</div>
<div class="firstCol">
    <ul>
        <li class="cat2">Footwear</li>
        <li>Flats</li>
        <li>Casual Shoes</li>
        <li>Heels</li>
        <li>Boots</li>
        <li>Sports Shoes & Floaters</li>
        <li id="lastList"></li>
    </ul>
    <ul>
        <li class="cat2">Sports & Active Wear</li>
        <li>Clothing</li>
        <li>Footwear</li>
        <li>Sports Accessories</li>
        <li>Sports Equipment</li>
    </ul>
</div>
<div class="firstCol backCol">
    <ul>
        <li class="cat2">Lingerie & Sleepwear</li>
        <li>Bra</li>
        <li>Briefs</li>
        <li>Shapewear</li>
        <li>Sleepwear & Loungewear</li>
        <li>Swimwear</li>
        <li>Camisoles & Thermals</li>
        <li id="lastList"></li>
    </ul>
    <ul>
        <li class="cat2">Beauty & Personal Care</li>
        <li>Makeup</li>
        <li>Skincare</li>
        <li>Premium Beauty</li>
        <li>Lipsticks</li>
        <li>Fragrances</li>
    </ul>
</div>
<div class="firstCol">
    <ul>
        <li class="cat2">Gadgets</li>
        <li>Smart Wearables</li>
        <li>Fitness Gadgets</li>
        <li>Headphones</li>
        <li>Speakers</li>
        <li id="lastList"></li>
    </ul>
    <ul>
        <li class="cat2">Jewellery</li>
        <li>Fashion Jewellery</li>
        <li>Fine Jewellery</li>
        <li>Earrings</li>
    </ul>
    <ul>
        <li class="cat2">Backpacks</li>
    </ul>
    <ul>
        <li class="cat2">Handbags, Bags & Wallets</li>
    </ul>
    <ul>
        <li class="cat2">Luggages & Trolleys</li>
    </ul>
</div>`
}

export default women;