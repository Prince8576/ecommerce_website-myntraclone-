const studio = () => {
    return`<div class="firstCol">
    <img id="studioImhg" src="https://constant.myntassets.com/web/assets/img/sudio-nav-banner.png" alt="">
    <button id="exploreStudio">EXPLORE STUDIO  ></button>
</div>`
}

export default studio;