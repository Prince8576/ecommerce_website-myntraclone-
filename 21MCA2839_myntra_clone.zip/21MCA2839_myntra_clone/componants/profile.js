const profile = () => {
    return `<ul>
    <li><strong>User</strong></li>
    <li>Mobile No.</li>
    <li id="lastList"></li>
    </ul>
    <ul>
        <li>Orders</li>
        <li>Wishlist</li>
        <li>Gift Cards</li>
        <li>Contact Us</li>
        <li>Myntra InsiderNew</li>
        <li id="lastList"></li>
    </ul>
    <ul>
        <li>Myntra Credit</li>
        <li>Coupons</li>
        <li>Saved Cards</li>
        <li>Saved Addresses</li>
        <li id="lastList"></li>
    </ul>
    <ul>
        <li>Edit Profile</li>
        <li>Logout</li>
    </ul>`
}

export default profile;