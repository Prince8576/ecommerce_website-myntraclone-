const beauty = () => {
    return `<div class="firstCol">
    <ul>
        <li class="cat5">Makeup</li>
        <li>Lipstick</li>
        <li>Lip Gloss</li>
        <li>Lip Liner</li>
        <li>Mascara</li>
        <li>Eyeliner</li>
        <li>Kajal</li>
        <li>Eyeshadow</li>
        <li>Foundation</li>
        <li>Primer</li>
        <li>Concealer</li>
        <li>Compact</li>
        <li>Nail Polish</li>
    </ul>
   </div>
   <div class="firstCol backCol">
    <ul>
        <li class="cat5">Skincare, Bath & Body</li>
        <li>Face Moisturiser</li>
        <li>Cleanser</li>
        <li>Masks & Peel</li>
        <li>Sunscreen</li>
        <li>Serum</li>
        <li>Face Wash</li>
        <li>Eye Cream</li>
        <li>Lip Balm</li>
        <li>Body Lotion</li>
        <li>Body Wash</li>
        <li>Body Scrub</li>
        <li>Hand Cream</li>
        <li id="lastList"></li>
    </ul>
    <ul>
        <li class="cat5">Baby Care</li>
    </ul>
    <ul>
        <li class="cat5">Masks</li>
    </ul>
   </div>
   <div class="firstCol">
    <ul>
        <li class="cat5">Haircare</li>
        <li>Shampoo</li>
        <li>Conditioner</li>
        <li>Hair Cream</li>
        <li>Hair Oil</li>
        <li>Hair Gel</li>
        <li>Hair Color</li>
        <li>Hair Serum</li>
        <li>Hair Accessory</li>
        <li id="lastList"></li>
    </ul>
    <ul>
        <li class="cat5">Fragrances</li>
        <li>Perfume</li>
        <li>Deodorant</li>
        <li>Body Mist</li>
    </ul>
   </div>
   <div class="firstCol backCol">
    <ul>
        <li class="cat5">Appliances</li>
        <li>Hair Straightener</li>
        <li>Hair Dryer</li>
        <li>Epilator</li>
        <li id="lastList"></li>
    </ul>
    <ul>
        <li>Men's Grooming</li>
        <li>Trimmers</li>
        <li>Beard Oil</li>
        <li>Hair Wax</li>
        <li id="lastList"></li>
    </ul>
    <ul>
        <li class="cat5">Beauty Gift & Makeup Set</li>
        <li>Beauty Gift</li>
        <li>Makeup Kit</li>
        <li id="lastList"></li>
    </ul>
    <ul>
        <li class="cat5">Premium Beauty</li>
    </ul>
    <ul>
        <li class="cat5">Wellness & Hygiene</li>
    </ul>
   </div>
   <div class="firstCol">
    <ul>
        <li class="cat5">Top Brands</li>
        <li>Lakme</li>
        <li>Maybelline</li>
        <li>LOreal</li>
        <li>Philips</li>
        <li>Bath & Body Works</li>
        <li>THE BODY SHOP</li>
        <li>Biotique</li>
        <li>Mamaearth</li>
        <li>MCaffeine</li>
        <li>Nivea</li>
        <li>Lotus Herbals</li>
        <li>LOreal Professionnel</li>
        <li>KAMA AYURVEDA</li>
        <li>M.A.C</li>
        <li>Forest Essentials</li>
    </ul> 
   </div>`
}

export default beauty;